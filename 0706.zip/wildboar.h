#pragma once
#include "enemy.h"

class wildboar
{
public:
	wildboar();
	~wildboar();
};

