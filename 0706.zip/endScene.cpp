#include "stdafx.h"
#include "endScene.h"


endScene::endScene()
{
}


endScene::~endScene()
{
}

HRESULT endScene::init(void)
{
	return S_OK;
}

void endScene::release(void)
{
}

void endScene::update(void)
{
}

void endScene::render(void)
{
}
