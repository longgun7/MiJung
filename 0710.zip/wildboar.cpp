#include "stdafx.h"
#include "wildboar.h"


wildboar::wildboar()
{
}


wildboar::~wildboar()
{
}
