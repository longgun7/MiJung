#include "stdafx.h"
#include "blackUniform.h"


HRESULT blackUniform::init()
{
	return S_OK;
}

void blackUniform::release()
{
}

void blackUniform::update()
{
}

void blackUniform::render()
{
}

blackUniform::blackUniform()
{
}


blackUniform::~blackUniform()
{
}
