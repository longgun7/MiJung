#include "stdafx.h"
#include "playScene.h"


playScene::playScene()
{
}


playScene::~playScene()
{
}

HRESULT playScene::init(void)
{
	

	SCENEMANAGER->changeScene("Ÿ���");

	return S_OK;
}

void playScene::release(void)
{
}

void playScene::update(void)
{

}


void playScene::render(void)
{
	
}
