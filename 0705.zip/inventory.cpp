#include "stdafx.h"
#include "inventory.h"


HRESULT inventory::init()
{
	return E_NOTIMPL;
}

void inventory::update()
{
}

void inventory::render()
{
}

void inventory::release()
{
}


inventory::inventory()
{
}


inventory::~inventory()
{
}
